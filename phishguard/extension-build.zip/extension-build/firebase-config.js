// Replace with your Firebase config
const firebaseConfig = {
  apiKey: "AIzaSyD5WwqiDw5uM09aiM4grQLQ2dHA4bz0Ni4",
  authDomain: "phisquard.firebaseapp.com",
  projectId: "phisquard",
  storageBucket: "phisquard.firebasestorage.app",
  messagingSenderId: "176259760839",
  appId: "1:176259760839:web:48aa4a54f5cb494246f4e2",
  measurementId: "G-EHGDV729BZ"
};

firebase.initializeApp(firebaseConfig);
